import telebot
from telebot import types

# Bot Token
BOT_TOKEN = '7986900653:AAH_wEgSFWCh3gP9qXfViqSFosT1muFPo2s'
bot = telebot.TeleBot(BOT_TOKEN)

# Admin ID
ADMIN_ID = 1360954628

# Free PDF link
FREE_PDF_LINK = 'https://t.me/filetobot/app?startapp=176a2133_22301028'
# Mini-course channel link
COURSE_LINK = 'https://t.me/+JphLxj5r-4g0OWZi'
# Payment card number
CARD_NUMBER = '8600130943115933'

# Store who pressed 'Tekshirish' last
awaiting_check = set()

@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    btn1 = types.KeyboardButton("📘 PDF ni yuklab olish")
    btn2 = types.KeyboardButton("🧘 Mini-kurs haqida")
    btn3 = types.KeyboardButton("💳 Sotib olish")
    btn4 = types.KeyboardButton("✅ Tekshirish")
    markup.add(btn1, btn2, btn3, btn4)

    bot.send_message(message.chat.id,
        "Assalomu alaykum, hurmatli foydalanuvchi! 👋

Quyidagi tugmalar orqali kerakli bo'limni tanlang:", reply_markup=markup)

@bot.message_handler(func=lambda message: message.text == "📘 PDF ni yuklab olish")
def send_pdf(message):
    bot.send_message(message.chat.id,
        f"📘 Bepul PDF faylingiz tayyor!
Quyidagi havolaga bosing 👇
{FREE_PDF_LINK}")

@bot.message_handler(func=lambda message: message.text == "🧘 Mini-kurs haqida")
def send_course_info(message):
    bot.send_message(message.chat.id,
        "Assalomu alaykum 🌿

"
        "Siz "10 kunlik Ruhiy Poklanish" mini kursiga predzapis qildingiz!

"
        "📘 Ushbu kurs sizga:
"
        "- Ichki osoyishtalik
"
        "- Qur'on va psixologiyadan birlashtirilgan amaliyotlar
"
        "- Har kuni 1 sahifalik ruhiy tozalanish ta'minlaydi.

"
        "🎯 Kursdan keyingi natijalar:

"
        "✅ Qalbingizda ichki sukunat paydo bo'ladi
"
        "✅ Aybdorlik va charchoq hissi kamayadi
"
        "✅ Fikringiz tiniqlashadi, duolaringiz chuqurlashadi
"
        "✅ Hayotingizda nima muhim — aniqlashni boshlaysiz
"
        "✅ Allohga suyanish osonlashadi
"
        "✅ O'zingizga rahm-shafqat bilan qaraysiz
"
        "✅ Ichki tartib va osoyishtalik bilan yashashga o'tasiz

"
        "🕊 Bu kurs — yuragingizni eslatish va poklash yo'li.

"
        "💸 *Narxi: 33 000 so'm*", parse_mode="Markdown")

@bot.message_handler(func=lambda message: message.text == "💳 Sotib olish")
def payment_info(message):
    bot.send_message(message.chat.id,
        f"👇 Kursni olish uchun to'lovni amalga oshiring:
💳 Karta raqami: *{CARD_NUMBER}*

✅ So'ngra to'lov cheki (skrinshot)ni shu yerga yuboring.",
        parse_mode="Markdown")
    awaiting_check.add(message.chat.id)

@bot.message_handler(func=lambda message: message.text == "✅ Tekshirish")
def check_payment(message):
    if message.chat.id in awaiting_check:
        awaiting_check.remove(message.chat.id)
        bot.send_message(message.chat.id,
            "💸 To'lovingiz muvaffaqiyatli qabul qilindi!

"
            "🧘🏻‍♀️ Endi siz "10 kunlik ruhiy poklanish" mini-kursiga to'liq kirdingiz.

"
            "Bu sayohat sizga:
"
            "— Qalbingizga sukunat,
"
            "— Hayotingizga tartib,
"
            "— Va Allohga yaqinlik olib keladi, in shaa Alloh.

"
            "Iltimos admin tomonidan tasdiq oling.")
    else:
        bot.send_message(message.chat.id,
            "❗️Avval 'Sotib olish' tugmasini bosing va to'lovni amalga oshiring.")

@bot.message_handler(commands=['tasdiqla'])
def confirm_payment(message):
    if message.from_user.id == ADMIN_ID:
        for chat_id in awaiting_check:
            bot.send_message(chat_id, f"📲 Telegram kanalga qo'shiling:
{COURSE_LINK}")
        bot.send_message(message.chat.id, "To'lov tasdiqlandi va kurs linklari yuborildi.")
    else:
        bot.send_message(message.chat.id, "Sizda bu buyruqni ishlatish huquqi yo'q.")

@bot.message_handler(content_types=['photo', 'document'])
def handle_payment_proof(message):
    bot.send_message(ADMIN_ID, f"🧾 Yangi to'lov skrinshoti yuborildi:
👤 @{message.from_user.username or 'Foydalanuvchi'}
🆔 ID: {message.from_user.id}")
    bot.forward_message(ADMIN_ID, message.chat.id, message.message_id)
    bot.send_message(message.chat.id, "✅ To‘lov skrinshotingiz qabul qilindi.
Iltimos, endi '✅ Tekshirish' tugmasini bosing.")

bot.polling()
